# PERN Task Manager

A minimal PERN stack task manager with multi-host support, dev/prod configs, migrations, and a Tailwind/Vite React frontend.
See `install_guide.txt` for full instructions.
